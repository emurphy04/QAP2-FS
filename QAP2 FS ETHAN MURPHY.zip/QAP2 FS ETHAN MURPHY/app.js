var http = require('http');
var fs = require('fs');
var EventEmitter = require('events');

var subscribeCount = 0

var SubCount = new EventEmitter.EventEmitter()

SubCount.on('subscribeCount', function(){
    subscribeCount++
    console.log(`${subscribeCount} Subscribers!`)
})

http.createServer((req, res)=>{
    res.writeHead(200, {"Content-Type": "text/html"})
    if(req.url == '/index' || req.url == '/'){
        var readStream = fs.createReadStream('index.html')
        readStream.pipe(res)
    } else if (req.url == '/about'){
        var readStream = fs.createReadStream('about.html')
        readStream.pipe(res)
    } else if (req.url == '/contact'){
        var readStream = fs.createReadStream('contact.html')
        readStream.pipe(res)
    } else if (req.url == '/products'){
        var readStream = fs.createReadStream('products.html')
        readStream.pipe(res)
    } else if (req.url == '/subscribe'){
        var readStream = fs.createReadStream('subscribe.html')
        readStream.pipe(res)
        SubCount.emit('subscribeCount', true)
    } else {
        var readStream = fs.createReadStream('404.html')
        readStream.pipe(res)
    }
    
}).listen(3000)
console.log("Server running on port 3000")